
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const readline = require('readline');
const dotenv = require('dotenv');

// Create interface for reading user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function main() {
  try {
    console.log('Starting build process...');
    
    // Read .env file
    const envPath = path.resolve('.env');
    let envConfig = {};
    
    if (fs.existsSync(envPath)) {
      envConfig = dotenv.parse(fs.readFileSync(envPath));
      console.log('Found .env file with the following variables:');
      
      const envVars = Object.keys(envConfig).filter(key => !key.startsWith('#') && envConfig[key]);
      
      if (envVars.length > 0) {
        // Read manifest file
        const manifestPath = path.resolve('manifest.json');
        if (fs.existsSync(manifestPath)) {
          const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
          
          // Check if the environment variables are in the manifest
          const configProperties = manifest.configSchema?.properties || {};
          const missingVars = envVars.filter(key => !configProperties[key.toLowerCase()]);
          
          if (missingVars.length > 0) {
            console.log('\nDetected environment variables not in manifest:');
            missingVars.forEach(key => console.log(`- ${key}`));
            
            // Ask if user wants to add these to manifest
            for (const key of missingVars) {
              const answer = await new Promise(resolve => {
                rl.question(`Add ${key} to manifest config? (y/n): `, resolve);
              });
              
              if (answer.toLowerCase() === 'y') {
                const description = await new Promise(resolve => {
                  rl.question(`Description for ${key}: `, resolve);
                });
                
                // Add to manifest config
                if (!manifest.configSchema) {
                  manifest.configSchema = {
                    type: 'object',
                    required: [],
                    properties: {}
                  };
                  manifest.hasConfig = true;
                }
                
                manifest.configSchema.properties[key.toLowerCase()] = {
                  type: 'string',
                  title: key,
                  description: description || `Configuration for ${key}`
                };
              }
            }
            
            // Save updated manifest
            fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
            console.log('\nManifest updated with new configuration options.');
          }
        }
      }
    }
    
    // Now run TypeScript compiler if needed
    if (fs.existsSync(path.resolve('tsconfig.json'))) {
      console.log('\nCompiling TypeScript...');
      // Clean any existing compiled files first
      if (fs.existsSync(path.resolve('bin'))) {
        const binFiles = fs.readdirSync(path.resolve('bin'));
        binFiles.forEach(file => {
          if (file.endsWith('.js') && file !== 'index.js') {
            fs.unlinkSync(path.resolve('bin', file));
          }
        });
      }
      execSync('tsc', { stdio: 'inherit' });
    }
    
    console.log('\nBuild completed successfully!');
  } catch (error) {
    console.error('Build failed:', error);
    process.exit(1);
  } finally {
    rl.close();
  }
}

main();
