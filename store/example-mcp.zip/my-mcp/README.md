# my-mcp

my-mcp MCP server

## Installation

1. Install dependencies:

```
npm install
```

2. Build the project:

```
npm run build
```

3. Start the MCP server:

```
npm start
```

## Configuration

This MCP server requires the following configuration:



## Supported AI Tools

- **Claude** (requires credentials)
- **Cursor** (requires credentials)

## License

MIT
